import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ContactFormController::__invoke
 * @see app/Http/Controllers/ContactFormController.php:14
 * @route '/contact'
 */
const ContactFormController = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ContactFormController.url(options),
    method: 'post',
})

ContactFormController.definition = {
    methods: ["post"],
    url: '/contact',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ContactFormController::__invoke
 * @see app/Http/Controllers/ContactFormController.php:14
 * @route '/contact'
 */
ContactFormController.url = (options?: RouteQueryOptions) => {
    return ContactFormController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContactFormController::__invoke
 * @see app/Http/Controllers/ContactFormController.php:14
 * @route '/contact'
 */
ContactFormController.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ContactFormController.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ContactFormController::__invoke
 * @see app/Http/Controllers/ContactFormController.php:14
 * @route '/contact'
 */
    const ContactFormControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: ContactFormController.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ContactFormController::__invoke
 * @see app/Http/Controllers/ContactFormController.php:14
 * @route '/contact'
 */
        ContactFormControllerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: ContactFormController.url(options),
            method: 'post',
        })
    
    ContactFormController.form = ContactFormControllerForm
export default ContactFormController