import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ContactMessageController::index
 * @see app/Http/Controllers/ContactMessageController.php:15
 * @route '/contact-messages'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/contact-messages',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ContactMessageController::index
 * @see app/Http/Controllers/ContactMessageController.php:15
 * @route '/contact-messages'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContactMessageController::index
 * @see app/Http/Controllers/ContactMessageController.php:15
 * @route '/contact-messages'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ContactMessageController::index
 * @see app/Http/Controllers/ContactMessageController.php:15
 * @route '/contact-messages'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ContactMessageController::index
 * @see app/Http/Controllers/ContactMessageController.php:15
 * @route '/contact-messages'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ContactMessageController::index
 * @see app/Http/Controllers/ContactMessageController.php:15
 * @route '/contact-messages'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ContactMessageController::index
 * @see app/Http/Controllers/ContactMessageController.php:15
 * @route '/contact-messages'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ContactMessageController::show
 * @see app/Http/Controllers/ContactMessageController.php:29
 * @route '/contact-messages/{contactMessage}'
 */
export const show = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/contact-messages/{contactMessage}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ContactMessageController::show
 * @see app/Http/Controllers/ContactMessageController.php:29
 * @route '/contact-messages/{contactMessage}'
 */
show.url = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { contactMessage: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { contactMessage: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    contactMessage: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        contactMessage: typeof args.contactMessage === 'object'
                ? args.contactMessage.id
                : args.contactMessage,
                }

    return show.definition.url
            .replace('{contactMessage}', parsedArgs.contactMessage.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContactMessageController::show
 * @see app/Http/Controllers/ContactMessageController.php:29
 * @route '/contact-messages/{contactMessage}'
 */
show.get = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ContactMessageController::show
 * @see app/Http/Controllers/ContactMessageController.php:29
 * @route '/contact-messages/{contactMessage}'
 */
show.head = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ContactMessageController::show
 * @see app/Http/Controllers/ContactMessageController.php:29
 * @route '/contact-messages/{contactMessage}'
 */
    const showForm = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ContactMessageController::show
 * @see app/Http/Controllers/ContactMessageController.php:29
 * @route '/contact-messages/{contactMessage}'
 */
        showForm.get = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ContactMessageController::show
 * @see app/Http/Controllers/ContactMessageController.php:29
 * @route '/contact-messages/{contactMessage}'
 */
        showForm.head = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ContactMessageController::markAsRead
 * @see app/Http/Controllers/ContactMessageController.php:41
 * @route '/contact-messages/{contactMessage}/mark-read'
 */
export const markAsRead = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAsRead.url(args, options),
    method: 'post',
})

markAsRead.definition = {
    methods: ["post"],
    url: '/contact-messages/{contactMessage}/mark-read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ContactMessageController::markAsRead
 * @see app/Http/Controllers/ContactMessageController.php:41
 * @route '/contact-messages/{contactMessage}/mark-read'
 */
markAsRead.url = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { contactMessage: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { contactMessage: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    contactMessage: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        contactMessage: typeof args.contactMessage === 'object'
                ? args.contactMessage.id
                : args.contactMessage,
                }

    return markAsRead.definition.url
            .replace('{contactMessage}', parsedArgs.contactMessage.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContactMessageController::markAsRead
 * @see app/Http/Controllers/ContactMessageController.php:41
 * @route '/contact-messages/{contactMessage}/mark-read'
 */
markAsRead.post = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAsRead.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ContactMessageController::markAsRead
 * @see app/Http/Controllers/ContactMessageController.php:41
 * @route '/contact-messages/{contactMessage}/mark-read'
 */
    const markAsReadForm = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markAsRead.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ContactMessageController::markAsRead
 * @see app/Http/Controllers/ContactMessageController.php:41
 * @route '/contact-messages/{contactMessage}/mark-read'
 */
        markAsReadForm.post = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markAsRead.url(args, options),
            method: 'post',
        })
    
    markAsRead.form = markAsReadForm
/**
* @see \App\Http\Controllers\ContactMessageController::destroy
 * @see app/Http/Controllers/ContactMessageController.php:51
 * @route '/contact-messages/{contactMessage}'
 */
export const destroy = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/contact-messages/{contactMessage}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ContactMessageController::destroy
 * @see app/Http/Controllers/ContactMessageController.php:51
 * @route '/contact-messages/{contactMessage}'
 */
destroy.url = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { contactMessage: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { contactMessage: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    contactMessage: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        contactMessage: typeof args.contactMessage === 'object'
                ? args.contactMessage.id
                : args.contactMessage,
                }

    return destroy.definition.url
            .replace('{contactMessage}', parsedArgs.contactMessage.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContactMessageController::destroy
 * @see app/Http/Controllers/ContactMessageController.php:51
 * @route '/contact-messages/{contactMessage}'
 */
destroy.delete = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ContactMessageController::destroy
 * @see app/Http/Controllers/ContactMessageController.php:51
 * @route '/contact-messages/{contactMessage}'
 */
    const destroyForm = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ContactMessageController::destroy
 * @see app/Http/Controllers/ContactMessageController.php:51
 * @route '/contact-messages/{contactMessage}'
 */
        destroyForm.delete = (args: { contactMessage: number | { id: number } } | [contactMessage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ContactMessageController = { index, show, markAsRead, destroy }

export default ContactMessageController