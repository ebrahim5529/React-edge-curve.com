import PortfolioController from './PortfolioController'
import ContactFormController from './ContactFormController'
import DashboardController from './DashboardController'
import PartnerController from './PartnerController'
import ProjectController from './ProjectController'
import MediaController from './MediaController'
import UserController from './UserController'
import ContactMessageController from './ContactMessageController'
import Settings from './Settings'
const Controllers = {
    PortfolioController: Object.assign(PortfolioController, PortfolioController),
ContactFormController: Object.assign(ContactFormController, ContactFormController),
DashboardController: Object.assign(DashboardController, DashboardController),
PartnerController: Object.assign(PartnerController, PartnerController),
ProjectController: Object.assign(ProjectController, ProjectController),
MediaController: Object.assign(MediaController, MediaController),
UserController: Object.assign(UserController, UserController),
ContactMessageController: Object.assign(ContactMessageController, ContactMessageController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers